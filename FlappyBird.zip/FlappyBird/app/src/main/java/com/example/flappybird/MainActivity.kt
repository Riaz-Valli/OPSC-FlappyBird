package com.example.flappybird


import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var startScreen: View
    private lateinit var gameView: GameView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        startScreen = findViewById(R.id.startScreen)
        gameView = findViewById(R.id.gameView)
    }

    fun startGame(view: View) {
        startScreen.visibility = View.GONE
        gameView.visibility = View.VISIBLE
        gameView.startGame()
    }
}
