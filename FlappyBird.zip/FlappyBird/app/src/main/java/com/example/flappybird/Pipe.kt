import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Rect
import com.example.flappybird.R

class Pipe(context: Context, screenWidth: Int, screenHeight: Int) {
    private val pipeBitmap: Bitmap = BitmapFactory.decodeResource(context.resources, R.drawable.pipe)
    private val gapHeight = 400
    private val minHeight = 200
    private var x = screenWidth
    private val yTop = (Math.random() * (screenHeight - gapHeight - minHeight)).toInt() + minHeight
    private val yBottom = yTop + gapHeight

    fun update() {
        x -= 10
    }

    fun draw(canvas: Canvas) {
        canvas.drawBitmap(pipeBitmap, null, Rect(x, yTop - pipeBitmap.height, x + pipeBitmap.width, yTop), null)
        canvas.drawBitmap(pipeBitmap, null, Rect(x, yBottom, x + pipeBitmap.width, yBottom + pipeBitmap.height), null)
    }

    fun isOffScreen(): Boolean {
        return x < -pipeBitmap.width
    }

    fun getTopRect(): Rect {
        return Rect(x, yTop - pipeBitmap.height, x + pipeBitmap.width, yTop)
    }

    fun getBottomRect(): Rect {
        return Rect(x, yBottom, x + pipeBitmap.width, yBottom + pipeBitmap.height)
    }
}
